// constucteur armes

function Weapons(name, idWeapon, dommages, shield) {
    this.name = name;
    this.idWeapon = idWeapon;
    this.dommages = dommages;
    this.shield = shield;
}


